#!/bin/bash

# Deploy script for Anti-Prompt Injection System
set -e

PROJECT_NAME="anti-prompt-injection"
AWS_REGION="us-east-1"
ECR_REPOSITORY=""

echo "🚀 Starting deployment of Anti-Prompt Injection System"
echo "=================================================="

# Check if AWS CLI is configured
if ! aws sts get-caller-identity > /dev/null 2>&1; then
    echo "❌ AWS CLI not configured. Please run 'aws configure' first."
    exit 1
fi

echo "✅ AWS CLI configured"

# Initialize Terraform
echo "📦 Initializing Terraform..."
terraform init

# Plan Terraform deployment
echo "📋 Planning Terraform deployment..."
terraform plan -out=tfplan

# Apply Terraform
echo "🏗️ Applying Terraform configuration..."
terraform apply tfplan

# Get ECR repository URL
ECR_REPOSITORY=$(terraform output -raw ecr_repository_url)
echo "📦 ECR Repository: $ECR_REPOSITORY"

# Build and push Docker image
echo "🐳 Building Docker image..."
cd ..

# Login to ECR
echo "🔐 Logging into ECR..."
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ECR_REPOSITORY

# Build image
docker build -t $PROJECT_NAME .

# Tag image
docker tag $PROJECT_NAME:latest $ECR_REPOSITORY:latest

# Push image
echo "📤 Pushing image to ECR..."
docker push $ECR_REPOSITORY:latest

# Update ECS service
echo "🔄 Updating ECS service..."
cd terraform
ECS_CLUSTER=$(terraform output -raw ecs_cluster_name)
ECS_SERVICE=$(terraform output -raw ecs_service_name)

aws ecs update-service \
    --cluster $ECS_CLUSTER \
    --service $ECS_SERVICE \
    --force-new-deployment \
    --region $AWS_REGION

# Get application URL
APP_URL=$(terraform output -raw load_balancer_url)

echo "=================================================="
echo "✅ Deployment completed successfully!"
echo "🌐 Application URL: $APP_URL"
echo "📊 Health Check: $APP_URL/health"
echo "🔍 API Endpoint: $APP_URL/api/v1/check-prompt"
echo "=================================================="
