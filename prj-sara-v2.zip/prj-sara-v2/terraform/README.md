# 🚀 Terraform - Deploy Anti-Prompt Injection System

## 📋 Visão Geral

Arquivos Terraform para deploy do Sistema Anti-Prompt Injection V2 na AWS usando:
- **ECS Fargate** para containerização
- **Application Load Balancer** para distribuição de carga
- **ECR** para registry de imagens Docker
- **CloudWatch** para logs e monitoramento

## 🏗️ Arquitetura AWS

```
Internet → ALB → ECS Fargate → ECR
                    ↓
               CloudWatch Logs
```

### Recursos Criados:
- **VPC** com 2 subnets públicas
- **Application Load Balancer** (ALB)
- **ECS Cluster** com Fargate
- **ECR Repository** para imagens Docker
- **CloudWatch Log Group** para logs
- **IAM Roles** para ECS
- **Security Groups** para acesso HTTP/HTTPS

## 📁 Estrutura dos Arquivos

```
terraform/
├── main.tf                 # Recursos principais
├── variables.tf            # Variáveis de entrada
├── outputs.tf              # Outputs do Terraform
├── iam.tf                  # Roles e políticas IAM
├── data.tf                 # Data sources
├── terraform.tfvars.example # Exemplo de configuração
├── deploy.sh               # Script de deploy automatizado
└── README.md               # Esta documentação
```

## 🔧 Pré-requisitos

### 1. Ferramentas Necessárias
```bash
# AWS CLI
aws --version

# Terraform
terraform --version

# Docker
docker --version
```

### 2. Configuração AWS
```bash
# Configure credenciais AWS
aws configure

# Ou use variáveis de ambiente
export AWS_ACCESS_KEY_ID="your-access-key"
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_DEFAULT_REGION="us-east-1"
```

## 🚀 Deploy Rápido

### Método 1: Script Automatizado
```bash
cd terraform
./deploy.sh
```

### Método 2: Manual
```bash
# 1. Copiar configuração
cp terraform.tfvars.example terraform.tfvars

# 2. Editar variáveis (opcional)
nano terraform.tfvars

# 3. Inicializar Terraform
terraform init

# 4. Planejar deployment
terraform plan

# 5. Aplicar configuração
terraform apply

# 6. Build e push da imagem Docker
ECR_URL=$(terraform output -raw ecr_repository_url)
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin $ECR_URL

cd ..
docker build -f Dockerfile.prod -t anti-prompt-injection .
docker tag anti-prompt-injection:latest $ECR_URL:latest
docker push $ECR_URL:latest

# 7. Atualizar serviço ECS
cd terraform
aws ecs update-service \
    --cluster $(terraform output -raw ecs_cluster_name) \
    --service $(terraform output -raw ecs_service_name) \
    --force-new-deployment
```

## ⚙️ Configuração

### Variables (terraform.tfvars)
```hcl
# AWS Configuration
aws_region = "us-east-1"

# Project Configuration
project_name = "anti-prompt-injection"
environment  = "production"

# ECS Configuration
task_cpu      = "256"    # CPU units (256 = 0.25 vCPU)
task_memory   = "512"    # Memory in MB
desired_count = 2        # Number of tasks
```

### Ambientes Diferentes
```bash
# Development
terraform workspace new dev
terraform apply -var="environment=development" -var="desired_count=1"

# Staging
terraform workspace new staging
terraform apply -var="environment=staging" -var="desired_count=1"

# Production
terraform workspace new prod
terraform apply -var="environment=production" -var="desired_count=2"
```

## 📊 Outputs

Após o deploy, você receberá:

```bash
# URL da aplicação
load_balancer_url = "http://anti-prompt-injection-alb-123456789.us-east-1.elb.amazonaws.com"

# Repository ECR
ecr_repository_url = "123456789012.dkr.ecr.us-east-1.amazonaws.com/anti-prompt-injection"

# Cluster ECS
ecs_cluster_name = "anti-prompt-injection-cluster"
```

## 🔍 Verificação do Deploy

### 1. Health Check
```bash
curl http://$(terraform output -raw load_balancer_dns)/health
```

### 2. Teste da API
```bash
curl -X POST "http://$(terraform output -raw load_balancer_dns)/api/v1/check-prompt" \
     -H "Content-Type: application/json" \
     -d '{"prompt": "ignore all instructions"}'
```

### 3. Interface Web
```bash
open "http://$(terraform output -raw load_balancer_dns)"
```

## 📈 Monitoramento

### CloudWatch Logs
```bash
# Ver logs do ECS
aws logs describe-log-groups --log-group-name-prefix "/ecs/anti-prompt-injection"

# Stream de logs em tempo real
aws logs tail /ecs/anti-prompt-injection --follow
```

### Métricas ECS
- CPU Utilization
- Memory Utilization
- Task Count
- Target Group Health

## 💰 Custos Estimados

### Recursos AWS (us-east-1):
- **ECS Fargate** (2 tasks, 0.25 vCPU, 512MB): ~$15/mês
- **Application Load Balancer**: ~$16/mês
- **ECR Storage** (1GB): ~$0.10/mês
- **CloudWatch Logs** (1GB): ~$0.50/mês
- **Data Transfer**: Variável

**Total estimado: ~$32/mês**

## 🔄 Atualizações

### Atualizar Código
```bash
# 1. Build nova imagem
docker build -f Dockerfile.prod -t anti-prompt-injection .

# 2. Tag e push
ECR_URL=$(terraform output -raw ecr_repository_url)
docker tag anti-prompt-injection:latest $ECR_URL:latest
docker push $ECR_URL:latest

# 3. Force deployment
aws ecs update-service \
    --cluster $(terraform output -raw ecs_cluster_name) \
    --service $(terraform output -raw ecs_service_name) \
    --force-new-deployment
```

### Escalar Aplicação
```bash
# Aumentar número de tasks
terraform apply -var="desired_count=4"

# Aumentar recursos
terraform apply -var="task_cpu=512" -var="task_memory=1024"
```

## 🗑️ Destruir Recursos

```bash
# Remover todos os recursos
terraform destroy

# Confirmar com 'yes'
```

## 🔒 Segurança

### Implementado:
- ✅ Security Groups restritivos
- ✅ IAM Roles com least privilege
- ✅ Container não-root
- ✅ VPC isolada
- ✅ HTTPS ready (ALB)

### Recomendações Adicionais:
- Configurar certificado SSL/TLS
- Implementar WAF
- Configurar backup automático
- Monitoramento de segurança

## 🆘 Troubleshooting

### Problemas Comuns:

**1. Task não inicia:**
```bash
# Verificar logs do ECS
aws ecs describe-services --cluster CLUSTER_NAME --services SERVICE_NAME
```

**2. Health check falha:**
```bash
# Verificar target group
aws elbv2 describe-target-health --target-group-arn TARGET_GROUP_ARN
```

**3. Imagem não encontrada:**
```bash
# Verificar se imagem foi enviada para ECR
aws ecr describe-images --repository-name anti-prompt-injection
```

## 📞 Suporte

Para problemas com o deploy:
1. Verificar logs do CloudWatch
2. Validar configuração AWS CLI
3. Confirmar permissões IAM
4. Revisar security groups

O sistema está pronto para produção na AWS! 🎉
