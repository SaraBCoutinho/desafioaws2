import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from pydantic import ValidationError
from src.models import PromptRequest, DetectionResponse, ErrorResponse, HealthResponse

def test_prompt_request_valid():
    """Teste: PromptRequest válido"""
    request = PromptRequest(prompt="Test prompt")
    assert request.prompt == "Test prompt"

def test_prompt_request_empty():
    """Teste: PromptRequest com prompt vazio deve falhar"""
    with pytest.raises(ValidationError):
        PromptRequest(prompt="")

def test_prompt_request_too_long():
    """Teste: PromptRequest muito longo deve falhar"""
    long_prompt = "a" * 10001
    with pytest.raises(ValidationError):
        PromptRequest(prompt=long_prompt)

def test_prompt_request_missing():
    """Teste: PromptRequest sem prompt deve falhar"""
    with pytest.raises(ValidationError):
        PromptRequest()

def test_detection_response_valid():
    """Teste: DetectionResponse válido"""
    response = DetectionResponse(
        detected=True,
        word_found="ignore",
        processing_time_ms=2.5,
        timestamp="2025-09-19T21:01:24.201Z"
    )
    assert response.detected == True
    assert response.word_found == "ignore"
    assert response.processing_time_ms == 2.5

def test_detection_response_no_word_found():
    """Teste: DetectionResponse sem palavra encontrada"""
    response = DetectionResponse(
        detected=False,
        word_found=None,
        processing_time_ms=1.0,
        timestamp="2025-09-19T21:01:24.201Z"
    )
    assert response.detected == False
    assert response.word_found is None

def test_error_response_valid():
    """Teste: ErrorResponse válido"""
    error = ErrorResponse(error="Test error", code="E001")
    assert error.error == "Test error"
    assert error.code == "E001"

def test_health_response_valid():
    """Teste: HealthResponse válido"""
    health = HealthResponse(status="ok", version="2.0.0")
    assert health.status == "ok"
    assert health.version == "2.0.0"
