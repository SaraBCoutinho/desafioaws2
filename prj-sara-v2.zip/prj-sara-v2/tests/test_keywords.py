import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.keywords import KEYWORDS

def test_keywords_list_exists():
    """Teste: lista de keywords existe"""
    assert KEYWORDS is not None
    assert isinstance(KEYWORDS, list)

def test_keywords_count():
    """Teste: número correto de keywords"""
    assert len(KEYWORDS) == 10

def test_keywords_content():
    """Teste: conteúdo das keywords"""
    expected_keywords = [
        "ignore", "forget", "system", "admin", "override",
        "bypass", "jailbreak", "prompt", "instruction", "command"
    ]
    
    assert KEYWORDS == expected_keywords

def test_keywords_are_lowercase():
    """Teste: todas as keywords estão em lowercase"""
    for keyword in KEYWORDS:
        assert keyword == keyword.lower()

def test_keywords_no_duplicates():
    """Teste: não há keywords duplicadas"""
    assert len(KEYWORDS) == len(set(KEYWORDS))

def test_keywords_are_strings():
    """Teste: todas as keywords são strings"""
    for keyword in KEYWORDS:
        assert isinstance(keyword, str)
        assert len(keyword) > 0
