from pydantic import BaseModel, Field
from typing import Optional

class PromptRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=10000, description="Prompt text to analyze")

class DetectionResponse(BaseModel):
    detected: bool = Field(..., description="Whether prompt injection was detected")
    word_found: Optional[str] = Field(None, description="The keyword that was found, if any")
    processing_time_ms: float = Field(..., description="Processing time in milliseconds")
    timestamp: str = Field(..., description="Timestamp of the analysis")

class ErrorResponse(BaseModel):
    error: str = Field(..., description="Error message")
    code: str = Field(..., description="Error code")

class HealthResponse(BaseModel):
    status: str = Field(..., description="Health status")
    version: str = Field(..., description="Application version")
