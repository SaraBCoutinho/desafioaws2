import os
import logging

# Configurações da aplicação
PORT = int(os.getenv("PORT", 8080))
MAX_PROMPT_LENGTH = int(os.getenv("MAX_PROMPT_LENGTH", 10000))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
VERSION = "2.0.0"

# Configuração de logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}',
    datefmt='%Y-%m-%dT%H:%M:%S.%fZ'
)

logger = logging.getLogger(__name__)
