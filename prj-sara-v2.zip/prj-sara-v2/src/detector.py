import time
from typing import Dict, Optional
from .keywords import KEYWORDS

def detect_injection(prompt: str) -> Dict:
    """
    Detecta prompt injection verificando presença das palavras-chave.
    
    Args:
        prompt: String do prompt a ser analisado
        
    Returns:
        Dict com resultado da detecção
    """
    start_time = time.time()
    
    # Normalização para lowercase
    normalized_prompt = prompt.lower()
    
    # Busca sequencial pelas palavras-chave
    for keyword in KEYWORDS:
        if keyword in normalized_prompt:
            processing_time = (time.time() - start_time) * 1000
            return {
                "detected": True,
                "word_found": keyword,
                "processing_time_ms": round(processing_time, 2),
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            }
    
    # Nenhuma palavra encontrada
    processing_time = (time.time() - start_time) * 1000
    return {
        "detected": False,
        "word_found": None,
        "processing_time_ms": round(processing_time, 2),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    }
