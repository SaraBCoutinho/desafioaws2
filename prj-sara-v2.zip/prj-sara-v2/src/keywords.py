# Lista das 10 palavras-chave mais relevantes para detecção de prompt injection
KEYWORDS = [
    "ignore",
    "forget", 
    "system",
    "admin",
    "override",
    "bypass",
    "jailbreak",
    "prompt",
    "instruction",
    "command"
]
